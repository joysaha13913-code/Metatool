package com.metaautocreator.app;

public class WorkerService2 extends BaseWorkerService {
    @Override protected int getWorkerId() { return 2; }
}
