package com.metaautocreator.app;

import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.HashSet;
import java.util.Random;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MailApiHelper {

    public static class MailAccount {
        public String email;
        public String ref; // email for GrabMail, sid_token for Guerrilla
    }

    private static String httpGet(String urlStr, String bearerToken) throws Exception {
        URL url = new URL(urlStr);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("GET");
        conn.setConnectTimeout(15000);
        conn.setReadTimeout(15000);
        conn.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36");
        if (bearerToken != null && !bearerToken.isEmpty()) {
            conn.setRequestProperty("Authorization", "Bearer " + bearerToken);
        }
        int code = conn.getResponseCode();
        if (code != 200) {
            conn.disconnect();
            return null;
        }
        BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = br.readLine()) != null) {
            sb.append(line);
        }
        br.close();
        conn.disconnect();
        return sb.toString();
    }

    public static MailAccount createAccount(String provider) throws Exception {
        MailAccount acc = new MailAccount();
        if ("Grab".equalsIgnoreCase(provider)) {
            String chars = "abcdefghijklmnopqrstuvwxyz0123456789";
            Random rnd = new Random();
            StringBuilder user = new StringBuilder();
            for (int i = 0; i < 10; i++) {
                user.append(chars.charAt(rnd.nextInt(chars.length())));
            }
            acc.email = user + "@grabmail.io";
            acc.ref = acc.email;
            return acc;
        } else {
            String resp = httpGet("https://api.guerrillamail.com/ajax.php?f=get_email_address", null);
            if (resp != null) {
                JSONObject json = new JSONObject(resp);
                acc.email = json.optString("email_addr", "");
                acc.ref = json.optString("sid_token", "");
                if (!acc.email.isEmpty() && !acc.ref.isEmpty()) {
                    return acc;
                }
            }
        }
        return null;
    }

    public static Set<String> getExistingMessageIds(String provider, String ref) {
        Set<String> ids = new HashSet<>();
        try {
            if ("Grab".equalsIgnoreCase(provider)) {
                String resp = httpGet("https://grabmail.io/api/v1/mailbox?address=" + URLEncoder.encode(ref, "UTF-8"), null);
                if (resp != null) {
                    JSONArray msgs = new JSONObject(resp).optJSONArray("messages");
                    if (msgs != null) {
                        for (int i = 0; i < msgs.length(); i++) {
                            String id = msgs.getJSONObject(i).optString("id", "");
                            if (!id.isEmpty()) ids.add(id);
                        }
                    }
                }
            } else {
                String resp = httpGet("https://api.guerrillamail.com/ajax.php?f=get_email_list&offset=0&sid_token=" + URLEncoder.encode(ref, "UTF-8"), null);
                if (resp != null) {
                    JSONArray list = new JSONObject(resp).optJSONArray("list");
                    if (list != null) {
                        for (int i = 0; i < list.length(); i++) {
                            String id = list.getJSONObject(i).optString("mail_id", "");
                            if (!id.isEmpty()) ids.add(id);
                        }
                    }
                }
            }
        } catch (Exception ignored) {
        }
        return ids;
    }

    public static String fetchNewOtp(String provider, String ref, Set<String> excludeIds) {
        Pattern otpPattern = Pattern.compile("(?<!#)\\b\\d{6}\\b");
        try {
            if ("Grab".equalsIgnoreCase(provider)) {
                String resp = httpGet("https://grabmail.io/api/v1/mailbox?address=" + URLEncoder.encode(ref, "UTF-8"), null);
                if (resp != null) {
                    JSONArray msgs = new JSONObject(resp).optJSONArray("messages");
                    if (msgs != null) {
                        for (int i = 0; i < msgs.length(); i++) {
                            JSONObject msg = msgs.getJSONObject(i);
                            String msgId = msg.optString("id", "");
                            if (msgId.isEmpty() || (excludeIds != null && excludeIds.contains(msgId))) continue;
                            String detail = httpGet("https://grabmail.io/api/v1/message/" + URLEncoder.encode(msgId, "UTF-8")
                                    + "?mailbox=" + URLEncoder.encode(ref, "UTF-8"), null);
                            String fullText = msg.optString("subject", "") + " " + (detail != null ? detail : "");
                            Matcher m = otpPattern.matcher(fullText);
                            if (m.find()) {
                                if (excludeIds != null) excludeIds.add(msgId);
                                return m.group(0);
                            }
                        }
                    }
                }
            } else {
                String resp = httpGet("https://api.guerrillamail.com/ajax.php?f=get_email_list&offset=0&sid_token=" + URLEncoder.encode(ref, "UTF-8"), null);
                if (resp != null) {
                    JSONArray list = new JSONObject(resp).optJSONArray("list");
                    if (list != null) {
                        for (int i = 0; i < list.length(); i++) {
                            JSONObject msg = list.getJSONObject(i);
                            String msgId = msg.optString("mail_id", "");
                            String subject = msg.optString("mail_subject", "");
                            String sender = msg.optString("mail_from", "").toLowerCase();
                            if (msgId.isEmpty() || (excludeIds != null && excludeIds.contains(msgId))) continue;
                            if (sender.contains("guerrilla") || subject.toLowerCase().contains("welcome")) continue;
                            if (sender.contains("meta") || sender.contains("facebook") || subject.toLowerCase().contains("meta")) {
                                String detail = httpGet("https://api.guerrillamail.com/ajax.php?f=fetch_email&email_id="
                                        + URLEncoder.encode(msgId, "UTF-8") + "&sid_token=" + URLEncoder.encode(ref, "UTF-8"), null);
                                String fullText = subject + " " + (detail != null ? detail : "");
                                Matcher m = otpPattern.matcher(fullText);
                                if (m.find()) {
                                    if (excludeIds != null) excludeIds.add(msgId);
                                    return m.group(0);
                                }
                            }
                        }
                    }
                }
            }
        } catch (Exception ignored) {
        }
        return null;
    }
}
