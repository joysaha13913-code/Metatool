package com.metaautocreator.app;

import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

public class XlsxExporter {

    private static String esc(String s) {
        if (s == null) return "";
        return s.replace("&", "&amp;")
                .replace("<", "&lt;")
                .replace(">", "&gt;")
                .replace("\"", "&quot;")
                .replace("'", "&apos;");
    }

    private static String colLetter(int colIndex) {
        StringBuilder sb = new StringBuilder();
        int n = colIndex;
        while (n >= 0) {
            sb.insert(0, (char) ('A' + (n % 26)));
            n = (n / 26) - 1;
        }
        return sb.toString();
    }

    public static void export(OutputStream os, List<MainActivity.ResultItem> items) throws Exception {
        try (ZipOutputStream zos = new ZipOutputStream(os)) {
            writeEntry(zos, "[Content_Types].xml",
                "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
                "<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\">" +
                "<Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/>" +
                "<Default Extension=\"xml\" ContentType=\"application/xml\"/>" +
                "<Override PartName=\"/xl/workbook.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml\"/>" +
                "<Override PartName=\"/xl/worksheets/sheet1.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/>" +
                "<Override PartName=\"/xl/styles.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml\"/>" +
                "</Types>");

            writeEntry(zos, "_rels/.rels",
                "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
                "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">" +
                "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"xl/workbook.xml\"/>" +
                "</Relationships>");

            writeEntry(zos, "xl/_rels/workbook.xml.rels",
                "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
                "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">" +
                "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet1.xml\"/>" +
                "<Relationship Id=\"rId2\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles\" Target=\"styles.xml\"/>" +
                "</Relationships>");

            writeEntry(zos, "xl/workbook.xml",
                "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
                "<workbook xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\" xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\">" +
                "<sheets><sheet name=\"Meta Accounts\" sheetId=\"1\" r:id=\"rId1\"/></sheets>" +
                "</workbook>");

            writeEntry(zos, "xl/styles.xml",
                "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
                "<styleSheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\">" +
                "<fonts count=\"2\">" +
                "<font><sz val=\"11\"/><name val=\"Calibri\"/></font>" +
                "<font><b/><sz val=\"11\"/><color rgb=\"FFFFFFFF\"/><name val=\"Calibri\"/></font>" +
                "</fonts>" +
                "<fills count=\"3\">" +
                "<fill><patternFill patternType=\"none\"/></fill>" +
                "<fill><patternFill patternType=\"gray125\"/></fill>" +
                "<fill><patternFill patternType=\"solid\"><fgColor rgb=\"FF1F4E78\"/></patternFill></fill>" +
                "</fills>" +
                "<borders count=\"2\">" +
                "<border><left/><right/><top/><bottom/><diagonal/></border>" +
                "<border><left style=\"thin\"><color auto=\"1\"/></left><right style=\"thin\"><color auto=\"1\"/></right><top style=\"thin\"><color auto=\"1\"/></top><bottom style=\"thin\"><color auto=\"1\"/></bottom><diagonal/></border>" +
                "</borders>" +
                "<cellStyleXfs count=\"1\"><xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\"/></cellStyleXfs>" +
                "<cellXfs count=\"2\">" +
                "<xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"1\" xfId=\"0\" applyBorder=\"1\"/>" +
                "<xf numFmtId=\"0\" fontId=\"1\" fillId=\"2\" borderId=\"1\" xfId=\"0\" applyFont=\"1\" applyFill=\"1\" applyBorder=\"1\"/>" +
                "</cellXfs>" +
                "</styleSheet>");

            StringBuilder sheet = new StringBuilder();
            sheet.append("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>");
            sheet.append("<worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\">");
            sheet.append("<cols>");
            sheet.append("<col min=\"1\" max=\"1\" width=\"6\" customWidth=\"1\"/>");
            sheet.append("<col min=\"2\" max=\"2\" width=\"30\" customWidth=\"1\"/>");
            sheet.append("<col min=\"3\" max=\"3\" width=\"18\" customWidth=\"1\"/>");
            sheet.append("<col min=\"4\" max=\"4\" width=\"16\" customWidth=\"1\"/>");
            sheet.append("<col min=\"5\" max=\"5\" width=\"36\" customWidth=\"1\"/>");
            sheet.append("<col min=\"6\" max=\"6\" width=\"12\" customWidth=\"1\"/>");
            sheet.append("<col min=\"7\" max=\"7\" width=\"20\" customWidth=\"1\"/>");
            sheet.append("</cols>");
            sheet.append("<sheetData>");

            String[] headers = {"SL", "Email", "Number", "Password", "2FA Secret", "Status", "Time"};
            sheet.append("<row r=\"1\">");
            for (int c = 0; c < headers.length; c++) {
                String ref = colLetter(c) + "1";
                sheet.append("<c r=\"").append(ref).append("\" s=\"1\" t=\"inlineStr\"><is><t>")
                     .append(esc(headers[c])).append("</t></is></c>");
            }
            sheet.append("</row>");

            for (int i = 0; i < items.size(); i++) {
                MainActivity.ResultItem r = items.get(i);
                int rowNum = i + 2;
                String[] vals = {
                    String.valueOf(i + 1),
                    r.email != null ? r.email : "",
                    r.phone != null ? r.phone : "",
                    r.password != null ? r.password : "",
                    r.twoFaKey != null ? r.twoFaKey : "",
                    r.status != null ? r.status : "",
                    r.timestamp != null ? r.timestamp : ""
                };
                sheet.append("<row r=\"").append(rowNum).append("\">");
                for (int c = 0; c < vals.length; c++) {
                    String ref = colLetter(c) + rowNum;
                    sheet.append("<c r=\"").append(ref).append("\" s=\"0\" t=\"inlineStr\"><is><t>")
                         .append(esc(vals[c])).append("</t></is></c>");
                }
                sheet.append("</row>");
            }

            sheet.append("</sheetData></worksheet>");
            writeEntry(zos, "xl/worksheets/sheet1.xml", sheet.toString());
        }
    }

    private static void writeEntry(ZipOutputStream zos, String name, String content) throws Exception {
        zos.putNextEntry(new ZipEntry(name));
        zos.write(content.getBytes(StandardCharsets.UTF_8));
        zos.closeEntry();
    }
}
