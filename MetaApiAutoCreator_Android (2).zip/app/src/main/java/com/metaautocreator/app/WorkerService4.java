package com.metaautocreator.app;

public class WorkerService4 extends BaseWorkerService {
    @Override protected int getWorkerId() { return 4; }
}
