package com.metaautocreator.app;

import android.os.Handler;
import android.webkit.CookieManager;
import android.webkit.WebStorage;
import android.webkit.WebView;

import org.json.JSONObject;

import java.util.Random;
import java.util.Set;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;

public class MetaAutomationEngine {

    public interface Callback {
        void onLog(String msg);
        boolean isRunning();
        double getSpeedMultiplier();
    }

    public static final String AUTH_URL = "https://auth.meta.com/?waterfall_id=2992ce49-32be-4fc5-8bb3-dc276e0a09bd&redirect_uri=https%3A%2F%2Fauth.meta.com%2Foidc%2F%3Fapp_id%3D1522763855472543%26redirect_uri%3Dhttps%253A%252F%252Fauth.meta.ai%252Fecto%26response_type%3Dcode%26scope%3Dopenid%252Blinking%26state%3DeyJjc3JmX3Rva2VuIjoidWVpN2EyNFhJY0xFR3h2UXEtY1lRUkhKOHZKR25FQ2luZ0htNk5UeGxZYyIsInJlZGlyZWN0X3RvIjoiaHR0cHM6Ly93d3cubWV0YS5haS9vaWRjL2NhbGxiYWNrIiwic3RhcnRlZF9hdCI6MTc5MTUzMTY0MzU5OSwid2F0ZXJmYWxsX2lkIjoiMjk5MmNlNDktMzJiZS00ZmM1LThiYjMtZGMyNzZlMGEwOWJkIn0%253D%26waterfall_id%3D2992ce49-32be-4fc5-8bb3-dc276e0a09bd%26code_challenge%3DSoV2XsXPO9EYS1aVS-aTlxbonOG6l5S8d0on4IfeWdU%26code_challenge_method%3DS256&source_app_id=1522763855472543&force_reauth=0";
    public static final String MUSE_URL = "https://muse.ai/?campaign_id=24452360397&extra_1=s%7Cc%7C831428651195%7Ce%7Cmuse+ai%7C&placement=&creative=831428651195&keyword=muse+ai&partner_id=googlesem";
    public static final String SECURITY_URL = "https://accountscenter.meta.com/password_and_security";
    public static final String CONTACT_URL = "https://accountscenter.meta.com/personal_info/contact_points";

    private final WebView webView;
    private final Handler mainHandler;
    private final Callback cb;
    private final Random random = new Random();

    public MetaAutomationEngine(WebView webView, Handler mainHandler, Callback cb) {
        this.webView = webView;
        this.mainHandler = mainHandler;
        this.cb = cb;
    }

    private void smartSleep(long ms) throws Exception {
        double mult = cb.getSpeedMultiplier();
        long adj = (long) (ms / mult);
        if (ms >= 500 && mult > 1.0) adj = Math.max(150, adj);
        long end = System.currentTimeMillis() + adj;
        while (System.currentTimeMillis() < end) {
            if (!cb.isRunning()) throw new Exception("Stopped by user");
            Thread.sleep(100);
        }
    }

    public void clearWebViewDataSync() {
        CountDownLatch latch = new CountDownLatch(1);
        mainHandler.post(() -> {
            try {
                CookieManager cm = CookieManager.getInstance();
                cm.removeAllCookies(null);
                cm.flush();
                WebStorage.getInstance().deleteAllData();
                webView.clearCache(true);
                webView.clearHistory();
                webView.loadUrl("about:blank");
            } catch (Exception ignored) {
            }
            latch.countDown();
        });
        try {
            latch.await(4, TimeUnit.SECONDS);
        } catch (InterruptedException ignored) {
        }
    }

    private void loadUrlSync(String url) throws Exception {
        mainHandler.post(() -> webView.loadUrl(url));
        smartSleep(2500);
        for (int i = 0; i < 20; i++) {
            if (!cb.isRunning()) throw new Exception("Stopped by user");
            String state = evalJs("return document.readyState;");
            if ("complete".equals(state)) break;
            smartSleep(400);
        }
    }

    private String evalJs(String body) {
        if (!cb.isRunning()) return "";
        AtomicReference<String> res = new AtomicReference<>("");
        CountDownLatch latch = new CountDownLatch(1);
        mainHandler.post(() -> webView.evaluateJavascript("(function(){" + body + "})()", value -> {
            if (value != null && !"null".equals(value)) {
                try {
                    if (value.startsWith("\"") && value.endsWith("\"")) {
                        res.set(new JSONObject("{\"v\":" + value + "}").optString("v", ""));
                    } else {
                        res.set(value);
                    }
                } catch (Exception e) {
                    res.set(value);
                }
            }
            latch.countDown();
        }));
        try {
            latch.await(8, TimeUnit.SECONDS);
        } catch (InterruptedException ignored) {
        }
        return res.get();
    }

    private boolean handleCookiesAndAccessDenied(int[] okCount) throws Exception {
        String lower = evalJs("return (document.body ? document.body.innerText : '').toLowerCase();");
        if (lower.contains("allow all cookies") || lower.contains("allow the use of cookies")) {
            evalJs("var bs=document.querySelectorAll('button,[role=button],span');for(var i=bs.length-1;i>=0;i--){if((bs[i].innerText||'').trim().toLowerCase()==='allow all cookies'){bs[i].click();return '1';}}return '0';");
            smartSleep(1500);
        }
        if (lower.contains("access denied") || lower.contains("not allowed to access this page")) {
            if (okCount[0] < 3) {
                evalJs("var bs=document.querySelectorAll('button,[role=button],span');for(var i=bs.length-1;i>=0;i--){if((bs[i].innerText||'').trim()==='OK'){bs[i].click();return '1';}}return '0';");
                okCount[0]++;
                cb.onLog("Access Denied -> clicked OK (" + okCount[0] + "/3)");
                smartSleep(1500);
                return true;
            }
            throw new Exception("Access Denied persisted after 3 OK clicks");
        }
        return false;
    }

    private boolean clickByTextJs(String targetText, int timeoutSec) throws Exception {
        long end = System.currentTimeMillis() + (timeoutSec * 1000L);
        String safe = targetText.replace("'", "\\'");
        while (System.currentTimeMillis() < end) {
            if (!cb.isRunning()) throw new Exception("Stopped by user");
            String clicked = evalJs(
                "var t='" + safe + "';" +
                "var els=document.querySelectorAll('button,[role=button],a,span,div');" +
                "for(var i=els.length-1;i>=0;i--){" +
                "  var el=els[i];" +
                "  if(!el.offsetParent && el.tagName!=='BODY') continue;" +
                "  if((el.innerText||'').trim()===t){" +
                "    var anc=el.closest('button,[role=button],a')||el;" +
                "    anc.scrollIntoView({block:'center'});" +
                "    anc.click();" +
                "    return '1';" +
                "  }" +
                "}return '0';"
            );
            if ("1".equals(clicked)) return true;
            smartSleep(500);
        }
        return false;
    }

    private boolean setInputValueJs(String cssSelector, String val) {
        String safeVal = val.replace("\\", "\\\\").replace("'", "\\'");
        String res = evalJs(
            "var inp=document.querySelector(\"" + cssSelector + "\");" +
            "if(!inp) return '0';" +
            "inp.scrollIntoView({block:'center'}); inp.focus();" +
            "var setter=Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype,'value').set;" +
            "setter.call(inp,'" + safeVal + "');" +
            "inp.dispatchEvent(new Event('input',{bubbles:true}));" +
            "inp.dispatchEvent(new Event('change',{bubbles:true}));" +
            "inp.dispatchEvent(new Event('blur',{bubbles:true}));" +
            "return '1';"
        );
        return "1".equals(res);
    }

    private boolean setOtpSmartJs(String otp) {
        String safeOtp = otp.replace("\\", "\\\\").replace("'", "\\'");
        String res = evalJs(
            "var otp='" + safeOtp + "';" +
            "var setter=Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype,'value').set;" +
            "var pins=Array.from(document.querySelectorAll('input[data-slot=\"pin-digit\"],input[maxlength=\"1\"]'));" +
            "if(pins.length>=6){" +
            "  for(var i=0;i<6&&i<otp.length;i++){" +
            "    pins[i].focus();" +
            "    setter.call(pins[i],otp[i]);" +
            "    pins[i].dispatchEvent(new Event('input',{bubbles:true}));" +
            "    pins[i].dispatchEvent(new Event('change',{bubbles:true}));" +
            "  }" +
            "  return '6';" +
            "}" +
            "var single=document.querySelector('input[maxlength=\"6\"],input[autocomplete=\"one-time-code\"],input[inputmode=\"numeric\"],input[type=\"tel\"],input');" +
            "if(!single) return '0';" +
            "single.focus();" +
            "setter.call(single,otp);" +
            "single.dispatchEvent(new Event('input',{bubbles:true}));" +
            "single.dispatchEvent(new Event('change',{bubbles:true}));" +
            "return '1';"
        );
        return !"0".equals(res) && !res.isEmpty();
    }

    private String generateBd10DigitPhone() {
        String[] prefixes = {"13", "14", "15", "16", "17", "18", "19"};
        StringBuilder sb = new StringBuilder(prefixes[random.nextInt(prefixes.length)]);
        for (int i = 0; i < 8; i++) sb.append(random.nextInt(10));
        return sb.toString();
    }

    private void selectBangladeshCountryAndSave() throws Exception {
        String body = evalJs("return (document.body?document.body.innerText:'').toLowerCase();");
        if (body.contains("bangladesh (+880)")) return;
        evalJs("var els=document.querySelectorAll('div,span,button,a');for(var i=els.length-1;i>=0;i--){var t=(els[i].innerText||'').trim();if(t==='Change'||t.indexOf('(+')!==-1){els[i].click();return '1';}}return '0';");
        smartSleep(1500);
        for (int i = 0; i < 15; i++) {
            if (!cb.isRunning()) throw new Exception("Stopped by user");
            String found = evalJs(
                "var els=document.querySelectorAll('div,span');" +
                "for(var i=0;i<els.length;i++){" +
                "  if((els[i].innerText||'').trim()==='Bangladesh (+880)'){" +
                "    els[i].scrollIntoView({block:'center'}); els[i].click(); return '1';" +
                "  }" +
                "}" +
                "var dlg=document.querySelector('div[role=dialog]');" +
                "if(dlg){var sc=Array.from(dlg.querySelectorAll('div')).find(d=>d.scrollHeight>d.clientHeight+20);if(sc)sc.scrollTop+=350;}" +
                "return '0';"
            );
            if ("1".equals(found)) {
                smartSleep(1000);
                clickByTextJs("Save", 8);
                smartSleep(1500);
                return;
            }
            smartSleep(400);
        }
    }

    public String executeCreateMetaAccount(MailApiHelper.MailAccount mail, String mailProvider, String pwd) throws Exception {
        int[] okCount = {0};
        cb.onLog("Opening auth.meta.com...");
        loadUrlSync(AUTH_URL);
        handleCookiesAndAccessDenied(okCount);

        if (!clickByTextJs("Use mobile number or email address", 15)) {
            clickByTextJs("Use mobile number or email", 5);
        }
        smartSleep(2000);
        handleCookiesAndAccessDenied(okCount);

        cb.onLog("Entering email: " + mail.email);
        setInputValueJs("input", mail.email);
        smartSleep(1200);
        clickByTextJs("Continue", 12);
        smartSleep(4000);
        handleCookiesAndAccessDenied(okCount);

        cb.onLog("Setting DOB & Password...");
        int day = 1 + random.nextInt(28);
        String[] months = {"January","February","March","April","May","June","July","August","September","October","November","December"};
        String month = months[random.nextInt(months.length)];
        int year = 1978 + random.nextInt(25);
        if (clickByTextJs("Day", 8)) { smartSleep(800); clickByTextJs(String.valueOf(day), 5); smartSleep(600); }
        if (clickByTextJs("Month", 8)) { smartSleep(800); clickByTextJs(month, 5); smartSleep(600); }
        if (clickByTextJs("Year", 8)) { smartSleep(800); clickByTextJs(String.valueOf(year), 5); smartSleep(600); }

        setInputValueJs("input[type='password']", pwd);
        smartSleep(1200);
        clickByTextJs("Continue", 12);
        smartSleep(5000);

        for (int i = 0; i < 3; i++) {
            if (handleCookiesAndAccessDenied(okCount)) smartSleep(1200);
            String pLow = evalJs("return (document.body?document.body.innerText:'').toLowerCase();");
            if (pLow.contains("edit your meta ai details") || pLow.contains("get started on meta ai")) {
                if (!clickByTextJs("Confirm", 4)) clickByTextJs("Continue", 4);
                smartSleep(4500);
                if (handleCookiesAndAccessDenied(okCount)) {
                    smartSleep(1000);
                    continue;
                }
            } else {
                break;
            }
        }

        // Redirect to muse.ai for OTP
        Set<String> oldMsgIds = MailApiHelper.getExistingMessageIds(mailProvider, mail.ref);
        boolean museReady = false;
        for (int t = 0; t < 3; t++) {
            cb.onLog("Opening muse.ai (try " + (t + 1) + ")...");
            loadUrlSync(MUSE_URL);
            smartSleep(2000);
            handleCookiesAndAccessDenied(okCount);

            // Wait up to 10s for skeleton to finish and input or 'Use phone or email' to appear
            boolean inputFound = false;
            for (int w = 0; w < 10; w++) {
                if (!cb.isRunning()) throw new Exception("Stopped by user");
                String hasInput = evalJs("return document.querySelector(\"input[inputmode='email'],input[data-slot='input'],input[type='email'],input\") ? '1' : '0';");
                if ("1".equals(hasInput)) {
                    inputFound = true;
                    break;
                }
                clickByTextJs("Use phone or email", 1);
                smartSleep(1000);
            }
            if (!inputFound) continue;

            if (!setInputValueJs("input[inputmode='email'],input[data-slot='input'],input[type='email'],input", mail.email)) continue;
            smartSleep(1000);
            oldMsgIds = MailApiHelper.getExistingMessageIds(mailProvider, mail.ref);
            if (!clickByTextJs("Continue", 10)) continue;

            // Poll up to 15s for PIN / OTP input screen
            cb.onLog("Waiting for muse.ai OTP screen...");
            for (int p = 0; p < 15; p++) {
                if (!cb.isRunning()) throw new Exception("Stopped by user");
                smartSleep(1000);
                handleCookiesAndAccessDenied(okCount);
                String hasPin = evalJs(
                    "if(document.querySelector('[data-slot=pin-digit],input[maxlength=\"6\"],input[autocomplete=\"one-time-code\"],input[inputmode=\"numeric\"]')) return '1';" +
                    "if(document.querySelectorAll('input[maxlength=\"1\"]').length>=6) return '1';" +
                    "var txt=(document.body?document.body.innerText:'').toLowerCase();" +
                    "if(txt.indexOf('enter the code')!==-1||txt.indexOf('confirmation code')!==-1||txt.indexOf('6-digit')!==-1) return '1';" +
                    "return '0';"
                );
                if ("1".equals(hasPin)) {
                    museReady = true;
                    break;
                }
            }
            if (museReady) break;
        }
        if (!museReady) throw new Exception("muse.ai OTP screen not reached");

        cb.onLog("Waiting NEW OTP from " + mailProvider + "...");
        String otp = null;
        for (int i = 0; i < 15; i++) {
            if (!cb.isRunning()) throw new Exception("Stopped by user");
            otp = MailApiHelper.fetchNewOtp(mailProvider, mail.ref, oldMsgIds);
            if (otp != null) break;
            smartSleep(3000);
        }
        if (otp == null) throw new Exception("OTP timeout");

        cb.onLog("Entering muse.ai OTP: " + otp);
        setOtpSmartJs(otp);
        smartSleep(1500);
        clickByTextJs("Continue", 3);
        smartSleep(5000);

        cb.onLog("Opening Accounts Center...");
        loadUrlSync(SECURITY_URL);
        handleCookiesAndAccessDenied(okCount);

        clickByTextJs("Two-factor authentication", 15);
        smartSleep(2500);
        clickByTextJs("Get started", 12);
        smartSleep(2000);

        evalJs("var r=document.querySelector(\"input[type='radio'][value='SMS']\");if(r){r.click();}");
        smartSleep(1000);
        clickByTextJs("Continue", 12);
        smartSleep(2500);

        selectBangladeshCountryAndSave();
        smartSleep(2000);
        String bd10 = generateBd10DigitPhone();
        cb.onLog("Entering BD 10-digit: " + bd10);
        setInputValueJs("input[type='tel'],input[autocomplete='tel-national']", bd10);
        smartSleep(2000);
        clickByTextJs("Next", 12);
        smartSleep(3500);

        cb.onLog("Adding Contact Info...");
        loadUrlSync(CONTACT_URL);
        handleCookiesAndAccessDenied(okCount);
        clickByTextJs("Add new contact info", 12);
        smartSleep(2000);
        clickByTextJs("Add mobile number", 12);
        smartSleep(2000);
        selectBangladeshCountryAndSave();
        setInputValueJs("input[type='tel'],input[autocomplete='tel-national']", bd10);
        smartSleep(1000);
        clickByTextJs("Next", 12);
        smartSleep(3500);

        cb.onLog("Deleting temp email...");
        loadUrlSync(CONTACT_URL);
        evalJs("var els=document.querySelectorAll('div,span');for(var i=0;i<els.length;i++){if((els[i].innerText||'').indexOf('" + mail.email + "')!==-1){els[i].click();return '1';}}return '0';");
        smartSleep(2500);
        clickByTextJs("Delete email address", 12);
        smartSleep(2000);
        clickByTextJs("Delete", 12);
        smartSleep(2500);
        setInputValueJs("input[type='password']", pwd);
        smartSleep(1000);
        clickByTextJs("Continue", 12);
        smartSleep(5000);

        return "880" + bd10;
    }

    public String execute2faForNumber(String number, String pwd) throws Exception {
        int[] okCount = {0};
        cb.onLog("2FA Login: " + number);
        loadUrlSync(SECURITY_URL);
        handleCookiesAndAccessDenied(okCount);

        String pLow = evalJs("return (document.body?document.body.innerText:'').toLowerCase();");
        if (pLow.contains("use mobile number or email")) {
            clickByTextJs("Use mobile number or email address", 12);
            smartSleep(2000);
            setInputValueJs("input[autocomplete='username'],input[type='text']", number);
            smartSleep(1000);
            clickByTextJs("Continue", 12);
            smartSleep(3500);
            clickByTextJs("Enter password instead", 12);
            smartSleep(2000);
            setInputValueJs("input[type='password']", pwd);
            smartSleep(1000);
            clickByTextJs("Continue", 12);
            smartSleep(4500);
            loadUrlSync(SECURITY_URL);
        }

        clickByTextJs("Two-factor authentication", 15);
        smartSleep(2500);
        clickByTextJs("Get started", 12);
        smartSleep(2000);
        evalJs("var r=document.querySelectorAll(\"input[type='radio']\");if(r.length>0&&!r[0].checked)r[0].click();");
        smartSleep(800);
        clickByTextJs("Continue", 12);
        smartSleep(2500);

        String twoFaKey = evalJs(
            "var dlg=document.querySelector('div[role=dialog]');" +
            "var txt=dlg?dlg.innerText:(document.body?document.body.innerText:'');" +
            "var lines=txt.split(/\\r?\\n/);" +
            "for(var i=0;i<lines.length;i++){" +
            "  var c=lines[i].replace(/\\s+/g,'').toUpperCase();" +
            "  if(c.length>=16 && c.length<=64 && /^[A-Z2-7]+$/.test(c) && /[2-7]/.test(c)) return c;" +
            "}return '';"
        );
        if (twoFaKey.isEmpty()) throw new Exception("2FA key not found");

        clickByTextJs("Enter code", 12);
        smartSleep(2000);

        String hasName = evalJs("var inp=document.querySelector(\"input[type='text']:not([maxlength='6'])\");return inp?'1':'0';");
        if ("1".equals(hasName)) {
            setInputValueJs("input[type='text']:not([maxlength='6'])", "MetaAuth" + (100 + random.nextInt(900)));
            smartSleep(800);
            clickByTextJs("Next", 10);
            smartSleep(2500);
        }

        int rem = TotpHelper.getRemainingSeconds();
        if (rem < 5) smartSleep((rem + 1) * 1000L);
        String totp = TotpHelper.generateTotp(twoFaKey);

        cb.onLog("Entering built-in 2FA TOTP: " + totp);
        setOtpSmartJs(totp);
        smartSleep(1000);
        clickByTextJs("Next", 12);
        smartSleep(3000);
        clickByTextJs("Done", 12);
        smartSleep(2000);

        return twoFaKey;
    }
}
